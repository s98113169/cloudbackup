<script type="text/javascript" src="/script/script.js"></script>
</body>
</html>